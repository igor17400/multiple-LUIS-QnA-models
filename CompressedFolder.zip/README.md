# Multiple LUIS and QnA models
This repository consists in a chatbot code for using several LUIS and QnA models from microsoft chatbot framework. 

I will be using 14.nlp-with-dispatch Microsoft's sample (https://github.com/Microsoft/BotBuilder-Samples/tree/master/samples/csharp_dotnetcore/14.nlp-with-dispatch). Therefore, the first step is to clone this code so we can use it as our guide through this document.

## Deploying the chatbot

To use our chatbot we need to deploy it to azure. 

Acess this link for futher reading about deploying chatbots to azure (https://docs.microsoft.com/en-us/azure/bot-service/bot-builder-deploy-az-cli?view=azure-bot-service-4.0&tabs=csharp). The following steps are just a synthezised version of this tutorial. 

1) Login to Azure and set subscription

```
az login
az account set --subscription "<azure-subscription>"
```

2) Execute the command below to create a new app registration into your Azure account

```
az ad app create --display-name "displayName" --password "AtLeastSixteenCharacters_0" --available-to-other-tenants
```

Command with parameters filled

```
    az ad app create --display-name "mult-registrations-app" --password "password_default" --available-to-other-tenants
```

3) Execute the command below to Deploy via ARM template (with new Resource Group)

```
az deployment create --template-file "<path-to-template-with-new-rg.json" --location <region-location-name> --parameters appId="<app-id-from-previous-step>" appSecret="<password-from-previous-step>" botId="<id or bot-app-service-name>" botSku=F0 newAppServicePlanName="<new-service-plan-name>" newWebAppName="<bot-app-service-name>" groupName="<new-group-name>" groupLocation="<region-location-name>" newAppServicePlanLocation="<region-location-name>" --name "<bot-app-service-name>"

```

The code below is the same as the above, however I have filled the required parameters. 

Remember! The majority of parameters are different, so pay atention to the values of yours'. This is just a example to how those parameters should be filled.    

```
az deployment create --template-file ".\DeploymentTemplates\template-with-new-rg.json" --location westus --parameters appId="519dfd8c-8d93-43d3-a3e8-ccbbd2d346d9" appSecret="password_default" botId="botMulti" botSku=F0 newAppServicePlanName="botMulti-service-plan" newWebAppName="botMulti-app-service" groupName="groupForMultiBot" groupLocation="westus" newAppServicePlanLocation="westus" --name "botMulti"

```

Afte this command you should see somehting similar to the image below into your azure resource group you just created.

<img src="images\image1.PNG"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" 
     heigh="100"
     width="700"/>

4) 